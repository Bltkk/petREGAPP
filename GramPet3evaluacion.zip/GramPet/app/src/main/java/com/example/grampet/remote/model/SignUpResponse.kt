package com.example.grampet.remote.model

data class SignUpResponse(
    val token: String
)
