// Archivo: app/src/main/java/com/example/grampet/MainActivity.kt
package com.example.grampet
// Archivo: app/src/main/java/com/example/grampet/MainActivity.kt


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier

// --- Import corregido para que coincida con tu paquete "navegation" ---
import com.example.grampet.navegation.AppNavigation
import com.example.grampet.ui.theme.GrampetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GrampetTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Ahora AppNavigation se encontrará sin problemas
                    AppNavigation()
                }
            }
        }
    }
}
