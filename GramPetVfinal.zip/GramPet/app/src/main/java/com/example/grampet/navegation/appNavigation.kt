package com.example.grampet.navegation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.grampet.screens.LoginScreen
import com.example.grampet.screens.MainScreen
import com.example.grampet.screens.SignUpScreen
import com.example.grampet.viewmodel.AuthViewModel
import com.example.grampet.viewmodel.PostsViewModel

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Routes.Login
    ) {
        composable(route = Routes.Login) {
            LoginScreen(
                authViewModel = authViewModel,
                onLoginSuccess = {
                    navController.navigate(Routes.Main) {
                        popUpTo(Routes.Login) { inclusive = true }
                    }
                },
                onNavigateToSignUp = {
                    navController.navigate(Routes.SignUp)
                }
            )
        }

        // ======================= BLOQUE MODIFICADO =======================
        composable(route = Routes.SignUp) {
            SignUpScreen(
                authViewModel = authViewModel,
                onSignUpSuccess = {
                    // Si el registro es exitoso, vuelve a la pantalla anterior (Login)
                    navController.popBackStack()
                },
                // --- CONEXIÓN DEL NUEVO BOTÓN ---
                // Al pulsar el botón "Volver", simplemente navega hacia atrás.
                onNavigateBackToLogin = {
                    navController.popBackStack()
                }
            )
        }
        // ======================= FIN DEL BLOQUE MODIFICADO =======================

        composable(route = Routes.Main) {
            val postsViewModel: PostsViewModel = viewModel()
            MainScreen(
                postsViewModel = postsViewModel,
                authViewModel = authViewModel,
                onLogoutSuccess = {
                    navController.navigate(Routes.Login) {
                        popUpTo(Routes.Main) { inclusive = true }
                    }
                }
            )
        }
    }
}
