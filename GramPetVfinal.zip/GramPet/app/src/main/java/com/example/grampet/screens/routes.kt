package com.example.grampet.screens



/**
 * Objeto que contiene las rutas de navegación de la aplicación como constantes.
 * Esto evita errores tipográficos y facilita la gestión de las rutas.
 */

