package com.example.grampet.viewmodel




import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.grampet.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// La data class Post no cambia
data class Post(
    val id: Int,
    val username: String,
    val model: Any, // Puede ser un Int (ID de drawable) o un Bitmap
    val description: String
)

class PostsViewModel : ViewModel() {
    private val _posts = MutableStateFlow<List<Post>>(emptyList())
    val posts = _posts.asStateFlow()

    private var nextPostId = 0

    // ======================= CÓDIGO RESTAURADO =======================
    // Hemos eliminado los comentarios para que este bloque se vuelva a ejecutar.
    // Ahora, al iniciar la app, se cargarán los posts de ejemplo.
    init {
        viewModelScope.launch {
            // Inicializa la lista con algunos posts de ejemplo
            val initialPosts = listOf(
                Post(1, "baltazar_dev", R.drawable.img_5, "¡Mi primera foto en Grampet!"),
                Post(2, "michi_aventurero", R.drawable.img_2, "Explorando nuevos horizontes."),
                Post(3, "firulais_viajero", R.drawable.img_1, "El mejor día en el parque."),
                Post(4, "doggo_feliz", R.drawable.img_3, "Hora de la siesta."),
                Post(5, "baltazar_dev", R.drawable.img_4, "Probando la cámara.")
            )
            _posts.value = initialPosts
            // Aseguramos que el próximo ID sea mayor que los existentes
            nextPostId = (initialPosts.maxOfOrNull { it.id } ?: 0) + 1
        }
    }
    // =====================================================================


    fun addPost(bitmap: Bitmap, description: String) {
        viewModelScope.launch {
            val newPost = Post(
                id = nextPostId++, // Asigna el ID y luego lo incrementa
                username = "baltazar_dev", // Por ahora, el usuario es fijo
                model = bitmap, // El modelo ahora es el Bitmap
                description = description
            )
            // Añade el nuevo post al principio de la lista
            _posts.value = listOf(newPost) + _posts.value
        }
    }
}

