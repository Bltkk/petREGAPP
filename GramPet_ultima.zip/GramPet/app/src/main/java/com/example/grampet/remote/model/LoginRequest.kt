package com.example.grampet.remote.model

data class LoginRequest(
    val email: String,
    val pass: String
)
