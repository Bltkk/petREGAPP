package com.example.grampet.remote.model

data class LoginResponse(
    val token: String
)
