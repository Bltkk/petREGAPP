package com.example.grampet.remote.model

data class PostResponse(
    val id: Int,
    val username: String,
    val imageUrl: String,
    val description: String
)
