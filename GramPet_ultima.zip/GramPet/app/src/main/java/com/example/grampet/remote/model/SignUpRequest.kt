package com.example.grampet.remote.model

data class SignUpRequest(
    val name: String,
    val email: String,
    val pass: String
)
